# BM05 - Bao Cao Sprint Review (Noi dung dien bieu mau)

## 1. Thong tin sprint

- Sprint: Sprint API Core Module
- Thoi gian: 01/03/2026 - 10/03/2026
- Muc tieu: Hoan thanh module API chinh phuc vu quan ly san pham, danh muc, khach hang

## 2. Tinh nang da hoan thanh

1. Thiet ke API theo REST cho module chinh
2. Xay dung 3 nhom endpoint CRUD day du:
   - Products
   - Categories
   - Customers
3. Tich hop validation dau vao cho tat ca params va body
4. Xay dung service layer tach biet va bo unit test
5. Hoan thanh tai lieu hoa (BM01 + BM05)

## 3. Ket qua ky thuat

- So endpoint CRUD: 15 endpoint (3 tai nguyen x 5 thao tac)
- Validation:
  - Param `id` bat buoc la so nguyen duong
  - Body create/update cho tung tai nguyen theo schema
  - Loi validation tra ve co `field` va `message`
- Unit test service layer:
  - Tong so test: 7
  - Test cac luong: doc danh sach, lay theo id, tao moi, cap nhat, xoa, va xu ly 404

## 4. Demo va kiem thu

- Chay API local: `npm start`
- Chay test: `npm test`
- Ket qua: tat ca test service layer pass

## 5. Van de ton dong / Ke hoach sprint tiep theo

- Van de ton dong:
  - Chua tich hop database that (hien tai dung in-memory repository)
  - Chua bo sung authentication/authorization cho endpoint
- Ke hoach sprint tiep theo:
  1. Chuyen repository sang MySQL/PostgreSQL
  2. Them auth JWT va phan quyen role
  3. Viet integration test cho API route
