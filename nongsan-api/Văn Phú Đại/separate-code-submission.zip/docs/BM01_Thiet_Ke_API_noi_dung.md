# BM01 - Thiet Ke API (Noi dung dien bieu mau)

## 1. Thong tin chung

- Ten do an: He thong thuong mai dien tu nong san
- Module chinh: Quan ly san pham, danh muc, khach hang
- Kieu kien truc API: RESTful JSON
- Base URL de xay dung/tich hop: `/api`

## 2. Quy uoc chung

- Dinh dang du lieu: `application/json`
- Ma phan hoi:
  - `200`: Thanh cong
  - `201`: Tao moi thanh cong
  - `400`: Du lieu dau vao khong hop le
  - `404`: Khong tim thay tai nguyen
  - `500`: Loi he thong

## 3. Dinh nghia endpoint CRUD

### 3.1 Products

- `GET /api/products`: Lay danh sach san pham
- `GET /api/products/{id}`: Lay chi tiet san pham
- `POST /api/products`: Tao san pham
- `PUT /api/products/{id}`: Cap nhat san pham
- `DELETE /api/products/{id}`: Xoa san pham

Payload tao/cap nhat:

```json
{
  "name": "Xoai Cat Hoa Loc",
  "price": 95000,
  "stock": 50,
  "categoryId": 1
}
```

Validation:

- `name`: chuoi 2-100 ky tu
- `price`: so duong
- `stock`: so nguyen >= 0
- `categoryId`: so nguyen duong

### 3.2 Categories

- `GET /api/categories`
- `GET /api/categories/{id}`
- `POST /api/categories`
- `PUT /api/categories/{id}`
- `DELETE /api/categories/{id}`

Payload tao/cap nhat:

```json
{
  "name": "Trai cay",
  "description": "Nhom san pham trai cay tuoi"
}
```

Validation:

- `name`: chuoi 2-80 ky tu
- `description`: chuoi 5-255 ky tu

### 3.3 Customers

- `GET /api/customers`
- `GET /api/customers/{id}`
- `POST /api/customers`
- `PUT /api/customers/{id}`
- `DELETE /api/customers/{id}`

Payload tao/cap nhat:

```json
{
  "fullName": "Nguyen Van B",
  "email": "vanb@example.com",
  "phone": "0912345678",
  "address": "12 Le Loi, Quan 1, TP.HCM"
}
```

Validation:

- `fullName`: chuoi 2-120 ky tu
- `email`: dung dinh dang email
- `phone`: theo regex `^(0|+84)[0-9]{9,10}$`
- `address`: chuoi 10-255 ky tu

## 4. Cau truc loi tra ve

```json
{
  "message": "Validation failed",
  "details": [
    {
      "field": "price",
      "message": "Number must be greater than 0"
    }
  ]
}
```

## 5. Vi du test nhanh

- Health check: `GET /health`
- Response:

```json
{
  "status": "ok",
  "module": "main-module-api"
}
```
