function buildValidationError(zodError) {
  const error = new Error("Validation failed");
  error.status = 400;
  error.details = zodError.issues.map((issue) => ({
    field: issue.path.join("."),
    message: issue.message,
  }));
  return error;
}

function validateBody(schema) {
  return (req, _res, next) => {
    const result = schema.safeParse(req.body);
    if (!result.success) {
      return next(buildValidationError(result.error));
    }
    req.body = result.data;
    return next();
  };
}

function validateParams(schema) {
  return (req, _res, next) => {
    const result = schema.safeParse(req.params);
    if (!result.success) {
      return next(buildValidationError(result.error));
    }
    req.params = result.data;
    return next();
  };
}

module.exports = {
  validateBody,
  validateParams,
};
