const { z } = require("zod");

const idParamSchema = z.object({
  id: z.coerce.number().int().positive(),
});

const productCreateSchema = z.object({
  name: z.string().trim().min(2).max(100),
  price: z.number().positive(),
  stock: z.number().int().nonnegative(),
  categoryId: z.number().int().positive(),
});

const productUpdateSchema = productCreateSchema.partial().refine(
  (payload) => Object.keys(payload).length > 0,
  "At least one field is required"
);

const categoryCreateSchema = z.object({
  name: z.string().trim().min(2).max(80),
  description: z.string().trim().min(5).max(255),
});

const categoryUpdateSchema = categoryCreateSchema.partial().refine(
  (payload) => Object.keys(payload).length > 0,
  "At least one field is required"
);

const customerCreateSchema = z.object({
  fullName: z.string().trim().min(2).max(120),
  email: z.string().trim().email(),
  phone: z.string().trim().regex(/^(0|\+84)[0-9]{9,10}$/),
  address: z.string().trim().min(10).max(255),
});

const customerUpdateSchema = customerCreateSchema.partial().refine(
  (payload) => Object.keys(payload).length > 0,
  "At least one field is required"
);

module.exports = {
  idParamSchema,
  productCreateSchema,
  productUpdateSchema,
  categoryCreateSchema,
  categoryUpdateSchema,
  customerCreateSchema,
  customerUpdateSchema,
};
