const { InMemoryRepository } = require("../repositories/inMemoryRepository");
const { buildCrudService } = require("./crudServiceFactory");
const {
  idParamSchema,
  productCreateSchema,
  productUpdateSchema,
  categoryCreateSchema,
  categoryUpdateSchema,
  customerCreateSchema,
  customerUpdateSchema,
} = require("../validators/schemas");

const productRepository = new InMemoryRepository([
  { id: 1, name: "Xoai Cat Chu", price: 85000, stock: 40, categoryId: 1 },
]);

const categoryRepository = new InMemoryRepository([
  { id: 1, name: "Trai Cay", description: "Nhom san pham trai cay tuoi" },
]);

const customerRepository = new InMemoryRepository([
  {
    id: 1,
    fullName: "Nguyen Van A",
    email: "vana@example.com",
    phone: "0912345678",
    address: "123 Nguyen Trai, Quan 1, TP.HCM",
  },
]);

const productService = buildCrudService({
  resourceName: "Product",
  repository: productRepository,
  schemas: {
    idParam: idParamSchema,
    create: productCreateSchema,
    update: productUpdateSchema,
  },
});

const categoryService = buildCrudService({
  resourceName: "Category",
  repository: categoryRepository,
  schemas: {
    idParam: idParamSchema,
    create: categoryCreateSchema,
    update: categoryUpdateSchema,
  },
});

const customerService = buildCrudService({
  resourceName: "Customer",
  repository: customerRepository,
  schemas: {
    idParam: idParamSchema,
    create: customerCreateSchema,
    update: customerUpdateSchema,
  },
});

module.exports = {
  productService,
  categoryService,
  customerService,
};
