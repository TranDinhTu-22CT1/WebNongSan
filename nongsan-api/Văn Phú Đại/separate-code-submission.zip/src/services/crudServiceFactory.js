function notFoundError(resourceName, id) {
  const error = new Error(`${resourceName} with id ${id} not found`);
  error.status = 404;
  return error;
}

function buildCrudService({ resourceName, repository, schemas }) {
  return {
    schemas,

    async getAll() {
      return repository.findAll();
    },

    async getById(id) {
      const item = repository.findById(id);
      if (!item) {
        throw notFoundError(resourceName, id);
      }
      return item;
    },

    async create(payload) {
      return repository.insert(payload);
    },

    async update(id, payload) {
      const updated = repository.update(id, payload);
      if (!updated) {
        throw notFoundError(resourceName, id);
      }
      return updated;
    },

    async remove(id) {
      const deleted = repository.delete(id);
      if (!deleted) {
        throw notFoundError(resourceName, id);
      }
      return deleted;
    },
  };
}

module.exports = { buildCrudService };
