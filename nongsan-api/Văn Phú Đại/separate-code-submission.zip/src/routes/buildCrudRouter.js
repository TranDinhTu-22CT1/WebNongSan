const express = require("express");
const {
  validateBody,
  validateParams,
} = require("../validators/validateRequest");

function buildCrudRouter(service) {
  const router = express.Router();

  router.get("/", async (_req, res, next) => {
    try {
      const data = await service.getAll();
      res.json({ data });
    } catch (error) {
      next(error);
    }
  });

  router.get("/:id", validateParams(service.schemas.idParam), async (req, res, next) => {
    try {
      const data = await service.getById(Number(req.params.id));
      res.json({ data });
    } catch (error) {
      next(error);
    }
  });

  router.post("/", validateBody(service.schemas.create), async (req, res, next) => {
    try {
      const created = await service.create(req.body);
      res.status(201).json({ data: created });
    } catch (error) {
      next(error);
    }
  });

  router.put(
    "/:id",
    validateParams(service.schemas.idParam),
    validateBody(service.schemas.update),
    async (req, res, next) => {
      try {
        const updated = await service.update(Number(req.params.id), req.body);
        res.json({ data: updated });
      } catch (error) {
        next(error);
      }
    }
  );

  router.delete("/:id", validateParams(service.schemas.idParam), async (req, res, next) => {
    try {
      const deleted = await service.remove(Number(req.params.id));
      res.json({ data: deleted });
    } catch (error) {
      next(error);
    }
  });

  return router;
}

module.exports = { buildCrudRouter };
