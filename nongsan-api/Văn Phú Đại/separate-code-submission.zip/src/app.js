const express = require("express");
const { buildCrudRouter } = require("./routes/buildCrudRouter");
const {
  productService,
  categoryService,
  customerService,
} = require("./services");

const app = express();
app.use(express.json());

app.get("/health", (_req, res) => {
  res.json({ status: "ok", module: "main-module-api" });
});

app.use("/api/products", buildCrudRouter(productService));
app.use("/api/categories", buildCrudRouter(categoryService));
app.use("/api/customers", buildCrudRouter(customerService));

app.use((err, _req, res, _next) => {
  const status = err.status || 500;
  res.status(status).json({
    message: err.message || "Internal server error",
    details: err.details || null,
  });
});

module.exports = app;
