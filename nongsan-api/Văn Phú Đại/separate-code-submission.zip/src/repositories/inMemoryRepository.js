class InMemoryRepository {
  constructor(seed = []) {
    this.items = [...seed];
    this.currentId =
      this.items.length > 0
        ? Math.max(...this.items.map((item) => item.id)) + 1
        : 1;
  }

  findAll() {
    return [...this.items];
  }

  findById(id) {
    return this.items.find((item) => item.id === id) || null;
  }

  insert(payload) {
    const newItem = { id: this.currentId++, ...payload };
    this.items.push(newItem);
    return newItem;
  }

  update(id, payload) {
    const index = this.items.findIndex((item) => item.id === id);
    if (index === -1) {
      return null;
    }

    this.items[index] = { ...this.items[index], ...payload };
    return this.items[index];
  }

  delete(id) {
    const index = this.items.findIndex((item) => item.id === id);
    if (index === -1) {
      return null;
    }

    const [deleted] = this.items.splice(index, 1);
    return deleted;
  }
}

module.exports = { InMemoryRepository };
