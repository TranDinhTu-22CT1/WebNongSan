# Separate Code Submission

This folder is fully isolated from the main project and contains:

1. API design artifact for the main module (form content)
2. At least 3 complete CRUD endpoints
3. Validation for all API inputs
4. At least 5 unit tests for service layer
5. Sprint Review report content (form content)

## Run

```bash
npm install
npm test
npm start
```

Server runs at `http://localhost:4000`.
